// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("lizard complexity"); }
int main(){
  announce();
  return lionss_run_workload("lizard-complexity");
}
