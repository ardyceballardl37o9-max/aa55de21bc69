// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("configure minimal"); }
int main(){
  announce();
  return lionss_run_workload("configure-minimal");
}
