// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("openbsd build\n", stdout);
  return lionss_run_workload("openbsd-build");
}
