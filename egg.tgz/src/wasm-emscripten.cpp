// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("wasm emscripten"); }
int main(){
  announce();
  return lionss_run_workload("wasm-emscripten");
}
