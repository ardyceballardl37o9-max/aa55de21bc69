// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("throughput bench\n", stdout);
  return lionss_run_workload("throughput-bench");
}
