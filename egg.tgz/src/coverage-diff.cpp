// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("coverage diff\n", stdout);
  return lionss_run_workload("coverage-diff");
}
